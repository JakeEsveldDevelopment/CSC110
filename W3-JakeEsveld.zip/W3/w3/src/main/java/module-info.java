module csc110.w3 {
    requires java.logging;
}
