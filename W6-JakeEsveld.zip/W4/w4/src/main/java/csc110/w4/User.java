package csc110.w4;

public class User implements Comparable{
    private String name;
    private String address;
    private String phone;

    public User(String name, String address, String phone){
        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    public User(){
        
    }

    public String toString(){
        return String.format("%s, %s, %s", name, address, phone);
    }

    public String getName(){
        return this.name;
    }

    public void setName(String name){
        this.name = name;
    }
    
    public String getAddress(){
        return this.address;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public String getPhone(){
        return this.phone;
    }

    public void setPhone(String phone){
        this.phone = phone;
    }

    @Override
    public int compareTo(Object o) {
        if(o instanceof User){
            return this.name.compareTo(((User)o).getName());
        }else{
            return 0;
        }
    }

}


