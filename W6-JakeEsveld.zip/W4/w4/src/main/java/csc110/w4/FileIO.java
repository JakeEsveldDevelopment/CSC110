package csc110.w4;

import static java.lang.System.out;
import java.nio.file.*;
import java.util.List;
import java.util.Stack;
import java.util.TreeSet;

import java.util.PriorityQueue;
import java.util.Queue;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;


public class FileIO {

    public static void main(String... args) throws IOException {
            String filename = "W4/w4/src/main/java/csc110/w4/Sample1000.csv";


            var filePath = Paths.get(filename);
            if(!Files.exists(filePath)){
                out.println("The File " + filename + " could not be found");
                return;
            }

            var reader = Files.newBufferedReader(filePath);
            var data = reader.readLine();
            var set = new TreeSet<String>();
            var list = new ArrayList<String>();
            var map = new HashMap<Integer, String>();
/*             Stack<User> stack = new Stack();
            PriorityQueue<User> queue = new PriorityQueue(); */
            data = reader.readLine();

            var counter = 0;
            while(data != null && data.length() > 0){
/*                 var elements = data.split(",");
                list.add(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim()));
 */
                set.add(data);
                list.add(data);
                map.put(counter, data);
                counter += 1;
                data = reader.readLine();
            }

            var start = System.currentTimeMillis();
            for(var user: set){
                out.println(user);
            }
            var stop = System.currentTimeMillis();
            var setTime = stop - start;
            out.println("SET TIME ELAPSED = " + String.valueOf(setTime));


            start = System.currentTimeMillis();
            for(var user: list){
                out.println(user);
            }
            stop = System.currentTimeMillis();
            var listTime = stop - start;
            out.println("ARRAYLIST TIME ELAPSED = " + String.valueOf(listTime));


            start = System.currentTimeMillis();
            for(int i=0; i < counter; i++){
                out.println(map.get(i));
            }
            stop = System.currentTimeMillis();
            var mapTime = stop - start;
            out.println("HASHMAP TIME ELAPSED = " + String.valueOf(mapTime));

            out.println("TIME COMPARISONS");
            out.println("LIST TIME = " + listTime);
            out.println("SET TIME = " + setTime);
            out.println("MAP TIME = " + mapTime);






/*                 stack.push(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim()));
                queue.add(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim())); */

/*             out.println("---------- NAMES ---------");
            for(var entry:list){
                out.println(entry.getName());
            }            
            
            out.println("---------- ADDRESSES ---------");
            for(var entry:list){
                out.println(entry.getAddress());
            }            
            
            out.println("---------- PHONES ---------");
            for(var entry:list){
                out.println(entry.getPhone());
            }

            out.println("-----------------------");

            out.println("---------- NAMES ---------");
            for(var entry:list){
                if(!entry.getName().startsWith("X")){
                    out.println(entry.getName());
                }
            }

            out.println("---------- STACK ----------");
            while(!stack.empty()){
                out.println(stack.pop().toString());
            }

            out.println("---------- QUEUE ----------");
            while(queue.peek() != null){
                out.println(queue.remove().toString());
            } */



           
/*            while(data != null){
                list.add("\n" + data);
                data = reader.readLine();
           }


           printData(list);

           for(String line: list){
               if(!line.trim().startsWith("X")){
                   out.println(line.trim());
               }
           } */
    }


/*     private static void printData(List<String> data){
        String header = data.get(0);
        String[] headers = header.split(",");
        for(int i =0; i < headers.length; i++){
            out.println("----------" + headers[i] + "s ----------");
            for(int k=1;k<data.size();k++){
                String initial = data.get(k);
                String[] breakDown = initial.split(",");
                out.println(breakDown[i]);
            }
        }
    } */
}
