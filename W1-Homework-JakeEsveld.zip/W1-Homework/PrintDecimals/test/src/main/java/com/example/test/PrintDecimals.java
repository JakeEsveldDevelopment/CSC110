package com.example.test;

import java.util.logging.Logger;
import static java.lang.System.out;

public class PrintDecimals {

    public static void main(String... args) {
        var number = 10.00045;
        var number1 = 4.584;
        var number2 = 7;
        var number3 = 932.4;
        var number4 = 0.0000001;
        var number5 = 2839;
        var number6 = 29455;
        var number7 = 10.25;
        var number8 = 11.1;
        var number9 = 2;
        var number10 = 192.45;
        out.println(number);
        out.println(number1);
        out.println(number2);
        out.println(number3);
        out.println(number4);
        out.println(number5);
        out.println(number6);
        out.println(number7);
        out.println(number8);
        out.println(number9);
        out.println(number10);
    
    }
}
