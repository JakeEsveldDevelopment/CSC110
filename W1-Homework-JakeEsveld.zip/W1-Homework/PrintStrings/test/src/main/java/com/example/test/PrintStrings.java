package com.example.test;

import java.util.logging.Logger;
import static java.lang.System.out;

public class PrintStrings {

    public static void main(String... args) {
        var name = "John Smith";
        out.println(name);
    }
}
