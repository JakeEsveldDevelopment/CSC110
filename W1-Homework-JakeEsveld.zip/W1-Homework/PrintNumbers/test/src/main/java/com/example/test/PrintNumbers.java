package com.example.test;

import java.util.logging.Logger;
import static java.lang.System.out;

public class PrintNumbers {

    public static void main(String... args) {
        var number = 0;
        out.println(number);
    }
}
