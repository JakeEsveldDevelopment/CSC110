module csc110.w4 {
    requires java.logging;
}
