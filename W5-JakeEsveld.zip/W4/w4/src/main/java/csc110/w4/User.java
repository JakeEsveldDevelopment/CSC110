package csc110.w4;

public class User {
    public String name;
    public String address;
    public String phone;
    
    public User(String name, String address, String phone){
        this.name = name;
        this.address = address;
        this.phone = phone;
    }
}
