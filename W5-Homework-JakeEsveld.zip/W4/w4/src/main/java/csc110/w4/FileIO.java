package csc110.w4;

import static java.lang.System.out;
import java.nio.file.*;
import java.util.List;
import java.util.Stack;
import java.util.PriorityQueue;
import java.util.Queue;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class FileIO {

    public static void main(String... args) throws IOException {
            String filename = "W4/w4/src/main/java/csc110/w4/data.txt";


            var filePath = Paths.get(filename);
            if(!Files.exists(filePath)){
                out.println("The File " + filename + " could not be found");
                return;
            }

            var reader = Files.newBufferedReader(filePath);
            var data = reader.readLine();
            List<User> list = new ArrayList();
            Stack<User> stack = new Stack();
            PriorityQueue<User> queue = new PriorityQueue();
            data = reader.readLine();

            while(data != null && data.length() > 0){
                var elements = data.split(",");
                list.add(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim()));
                stack.push(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim()));
                queue.add(new User(elements[0].trim(),
                    elements[1].trim(),
                    elements[2].trim()));
                data = reader.readLine();
            }

            out.println("---------- NAMES ---------");
            for(var entry:list){
                out.println(entry.getName());
            }            
            
            out.println("---------- ADDRESSES ---------");
            for(var entry:list){
                out.println(entry.getAddress());
            }            
            
            out.println("---------- PHONES ---------");
            for(var entry:list){
                out.println(entry.getPhone());
            }

            out.println("-----------------------");

            out.println("---------- NAMES ---------");
            for(var entry:list){
                if(!entry.getName().startsWith("X")){
                    out.println(entry.getName());
                }
            }

            out.println("---------- STACK ----------");
            while(!stack.empty()){
                out.println(stack.pop().toString());
            }

            out.println("---------- QUEUE ----------");
            while(queue.peek() != null){
                out.println(queue.remove().toString());
            }



           
/*            while(data != null){
                list.add("\n" + data);
                data = reader.readLine();
           }


           printData(list);

           for(String line: list){
               if(!line.trim().startsWith("X")){
                   out.println(line.trim());
               }
           } */
    }


/*     private static void printData(List<String> data){
        String header = data.get(0);
        String[] headers = header.split(",");
        for(int i =0; i < headers.length; i++){
            out.println("----------" + headers[i] + "s ----------");
            for(int k=1;k<data.size();k++){
                String initial = data.get(k);
                String[] breakDown = initial.split(",");
                out.println(breakDown[i]);
            }
        }
    } */
}
