module com.example.test {
    requires java.logging;
}
